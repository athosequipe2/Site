<?php
$HOST='localhost';
$DB_NAME='sae';
$USER='root';
$PASS='';
?>