<!DOCTYPE html>
<html lang="fr">
	<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
		<meta charset="utf-8"/>
		<title>Stage</title>
		<link rel="stylesheet" href="Content/css/nobel.css"/>
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600">
		<!-- https://fonts.google.com/specimen/Open+Sans -->
		<link rel="stylesheet" href="Content/css/fontawesome.min.css">
		<!-- https://fontawesome.com/ -->
		<link rel="stylesheet" href="Content/css/bootstrap.min.css">
		<!-- https://getbootstrap.com/ -->
		<link rel="stylesheet" href="Content/css/tooplate.css">
		<!-- https://fontawesome.com/ -->
		<link rel="stylesheet" href="Content/jquery-ui-datepicker/jquery-ui.min.css" type="text/css" />
		<!-- http://api.jqueryui.com/datepicker/ -->

	</head>
