<script src="Content/js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="Content/js/moment.min.js"></script>
    <!-- https://momentjs.com/ -->
    <script src="Content/js/utils.js"></script>
    <script src="Content/js/Chart.min.js"></script>
    <!-- http://www.chartjs.org/docs/latest/ -->
    <script src="Content/js/fullcalendar.min.js"></script>
    <!-- https://fullcalendar.io/ -->
    <script src="Content/js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
    <script src="Content/js/tooplate-scripts.js"></script>
    <script>

</main>
</body>
</html>
