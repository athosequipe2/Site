<?php require "view_begin.php"?>

<body class="bg02">
<?php require "view_navigation.php"?>
        <!-- row -->
        <div class="row tm-mt-big">
            <div class="col-xl-8 col-lg-10 col-md-12 col-sm-12">
              <from action="?controller=acceuil&action=acceuil" method="post">
                <div class="grandblock">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="tm-block-title d-inline-block">Profil étudiant</h2>
                        </div>
                    </div>

                    <div class="row mt-4 tm-edit-product-row">
                        <div class="col-xl-7 col-lg-7 col-md-12">
                            <form action="" class="tm-edit-product-form">
                                <div class="input-group mb-3">
                                    <label for="name" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Nom Prénom
                                    </label>
                                    <label for="name" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label"><?= $liste["nom"] ?> <?= $liste["prenom"] ?>
                                    </label>
                                </div>
                                <div class="input-group mb-3">
                                    <label for="description" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 mb-2">Information</label>
                                    <label for="description" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 mb-2"><?= $liste["student_id"] ?> <br> <?= $liste["groupe"] ?> <br> <?= $liste["departement"] ?></label>
                                </div>
                                <div class="input-group mb-3">
                                    <label for="expire_date" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">
                                        Dernière modification
                                    </label>
                                    <label for="expire_date" class="form-control validate col-xl-9 col-lg-8 col-md-8 col-sm-7">
                                        <?= $liste["date_heure"] ?>
                                    </label>

                                </div>
                                <div class="input-group mb-3">
                                    <label for="category" class="col-xl-4 col-lg-4 col-md-4 col-sm-5 col-form-label">Etat</label>
                                    <select class="custom-select col-xl-9 col-lg-8 col-md-8 col-sm-7" id="category">
                                        <option value="1" name="valider" selected>Valider</option>
                                        <option value="2" name="en attente">En attente</option>
                                        <option value="3" name="Refuser">Refuser</option>
                                    </select>
                                </div>

                            </form>
                        </div>
                    </div>
                    <div class="imgbos">
                        <div>
                            <center><h4>Feuille de route</h4> </center>
                            <img src="Content/img/fichederoute.png" alt="Profile Image" class="img-fluid mx-auto d-block">
                            <div class="custom-file mt-3 mb-3">
                                <div class="input-group mt-3">
                                    <button type="button" class="btn btn-primary d-inline-block mx-auto" name="formlogin"><a href=<?= $liste["url"]?>>Voir</a></button>
                                </div>
                            </div>
                        </div>
                        <div>
                          <br>
                            <center><h4>Bordereau de stage </h4> </center>
                            <img src="Content/img/bordereau.png" alt="Profile Image" class="img-fluid mx-auto d-block">
                            <div class="custom-file mt-3 mb-3">
                                <input type="button" href=<?= $liste["url"]?> class="btn btn-primary d-block mx-auto" value="Voir";
                                />
                            </div>
                        </div>

                    </div>
                    <div class="confirmer">
                        <div class="input-group mb-3">
                            <div class="ml-auto col-xl-8 col-lg-8 col-md-8 col-sm-7 pl-0">
                                <button type="submit" class="btn btn-primary">Confirmer
                                </button>
                            </div>
                        </div>

                    </div>
                  </from>
            </div>
        </div>
    </div>

<?php require "view_end.php"?>
