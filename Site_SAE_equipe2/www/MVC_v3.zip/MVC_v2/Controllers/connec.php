<?php
$HOST='localhost';
$DB_NAME='aquabdd';
$USER='12104997';
$PASS='071776937fg';
?>
